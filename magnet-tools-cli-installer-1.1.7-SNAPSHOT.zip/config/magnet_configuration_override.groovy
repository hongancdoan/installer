// Magnet configuration override file
// You can override default magnet configuration value in this config groovy file

// developer center URL
//developerCenterURL = new URL("https://factory.magnet.com")
// artifactory root repository
//magnetMavenRepositoryURL = new URL("https://repo.magnet.com/artifactory")
